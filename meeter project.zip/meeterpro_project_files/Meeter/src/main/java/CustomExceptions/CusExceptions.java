package CustomExceptions;

public class CusExceptions extends Exception
{
		
	public  NullUsername	emptyusername()
	{
		return new NullUsername();
	}
	
	public  UserNotFound NoSuchUser()
	{
		return new UserNotFound();
	}

	public  passwordTooLongOrShort passworderror()
	{
		return new passwordTooLongOrShort();
	}
	
	public EmptyPass passwordEmpty()
	{
		return new EmptyPass(); 
	}
	
	public wrongPass invalidPass()
	{
		return new wrongPass(); 
	}
	
	public static NullConnection NoConnection()
	{
		return new NullConnection();
	}

	// This Section contains exception throwers for the "New User signup phase"
	
	public static SimilarUserNameExists repeatedUserName()
	{
		return new SimilarUserNameExists();
	}
	
	// posts related exceptions

	public Spaceinpass spass()
	{
		return new Spaceinpass();
	}
	
	public Invalidemail inemail()
	{
		return new Invalidemail();
	}
	
	public Invalidgen ingen()
	{
		return new Invalidgen();
	}
	
	public Invalidadd inadd()
	{
		return new Invalidadd();
	}
}


//various error classes
class passwordTooLongOrShort extends Exception
{
	public passwordTooLongOrShort()
	{
		System.err.println("                    The password is too long or short");
	}
}


class NullUsername extends Exception
{
	public NullUsername()
	{
	System.err.println("                       The user name cannot be empty.");
	}
}

class SimilarUserNameExists extends Exception
{
	public SimilarUserNameExists()
	{
		System.err.println("          This username aleready Exists try some another username.");
	}
}

class UserNotFound extends Exception
{
	public UserNotFound()
	{
		System.err.println("                 The user could not be found or Account does not exist.");
		System.err.println("                           Try creating a new account.");
	}
}

class EmptyPass extends Exception
{
	public EmptyPass()
	{
		System.err.println("                       The password Should not be empty");
	}
}

class wrongPass extends Exception
{
	public wrongPass()
	{
		System.err.println("                             The password is wrong.");
	}
}


class NullConnection extends Exception
{
	public NullConnection()
	{
		System.err.println("                        The conncetion is broken please fix!");
	}
}
class Spaceinpass extends Exception
{
	public Spaceinpass()
	{
		System.err.println("                         The conncetion is broken please fix!");
	}
}

 class Invalidemail extends Exception
{
	public Invalidemail()
	{
		System.err.println("                                   The email is invalid");
	}
}

class Invalidgen extends Exception
{
	public Invalidgen()
	{
		System.err.println("                                     The Gender is invalid");
	}
}
class Invalidadd extends Exception
{
	public Invalidadd()
	{
		System.err.println("The add is too long or short");
	}
}