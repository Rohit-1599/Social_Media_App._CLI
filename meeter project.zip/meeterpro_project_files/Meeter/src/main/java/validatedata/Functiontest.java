package validatedata;

import java.io.FileReader;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import java.util.Scanner;

import CustomExceptions.CusExceptions;

public class Functiontest
{
	public static void main(String[] args) throws Exception
	{
		Properties prop = new Properties();
		prop.load(new FileReader("C:\\Users\\komal\\Desktop\\project workspace\\meeterpro.zip_expanded\\Meeter\\src\\main\\java\\resources\\props.properties"));
		Connection conn = DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
		Statement cs ;
		ResultSet r;
		PreparedStatement stmt;
		String username = "rohit";
		Scanner sc = new Scanner(System.in);
		
		cs = conn.createStatement();
		stmt = conn.prepareStatement("SELECT Userid ,username FROM userinfo where username = ?");
		stmt.setString(1,username);
		r = stmt.executeQuery();
		
		 int userid = 0;
		 
		 System.out.println(r.next());
//		 try 
//		 {
//			 
//			 while(r.next())
//			 {
//				if(username.equals(r.getString(2)))
//				{
//				  userid = r.getInt(1);
//				}
//				else
//				{
//					CusExceptions cus = new CusExceptions();
//					throw cus.NoSuchUser();
//				}
//			}
//				 
//		 }
//		 catch(Exception e)
//		 {
//		 	if(e.getMessage().contains("empty"))
//		 	{
//		 		userid = 0;
//		 	}
//		 }
	
		 System.out.println(userid);
	
	
	}

}
