package com.meeter.Meeter;

import java.util.Scanner;
import com.Controller.Controller;
import com.Decoretor.Printer;

public class App 
{

	public static void main( String[] args ) 
    {
		    
	    	Scanner sc = new Scanner(System.in);
	    	Controller cont  = new Controller();
	    	String ans ="yes";
	    	
	    	while(ans.equalsIgnoreCase("yes"))
	    	{
	    		Printer.logo();
		    	Printer.mainmenu();
		    	switch(sc.nextInt())
		    	{
		    		case 1: cont.login();
		    			    break;
		    			
		    		case 2: cont.signUp();
		    				break;
		    				
		    		default: ans = "yes";
		    				break;
		    	}
		    	
		    	System.out.print("             Do you want to continue with main menu(yes/no): ");
		    	ans = sc.next();
		    	
	    	}
	    	System.out.println("                      Thank you for useing Meeter! ");
	    	
		
    }
}
