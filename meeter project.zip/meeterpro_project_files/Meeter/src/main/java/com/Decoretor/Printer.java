package com.Decoretor;

public class Printer
{
	public static void logo()
	{
		newlines();
		System.out.println("                             /\\~~~~~~~~~~~~~~~~~~~~~/\\  ");
		System.out.println("                            /  \\                   /  \\ ");
		System.out.println("                           /    \\_________________/    \\");
		System.out.println("                           |___________________________|");
		System.out.println("                           |                           |");
		System.out.println("                           |                           |");
		System.out.println("                           |         MEETER            |");
		System.out.println("                           |                           |");
		System.out.println("                           |All your friend's are here!|");
		System.out.println("                           |                           |");
		System.out.println("                           |___________________________|");
		
	}
	
	public static void mainmenu()
	{
		System.out.println("\n\n                                   \\/\\/elcome!       ");
		System.out.println("\n                               1.Login     2.Signup");
		System.out.print("                               :-");
	} 
	
	public static void loggedinmenu()
	{

		System.out.println("\n                                                        ");
		System.out.println("                                  1.View My Profile   ");
		System.out.println("                                  2.View All Profile's");
		System.out.println("                                  3.Update my Profile"); 
		System.out.println("                                  4.Show my Timeline  \n ");
		System.out.print("                                  :-  ");
	}
	public static void newlines()
	{
		System.out.println("\n\n\n\n\n\n");
	}
	
	public static void updateMenu()
	{
		System.out.println("\n                                                        ");
		System.out.println("                                  1.Update UserName   ");
		System.out.println("                                  2.Update Password");
		System.out.println("                                  3.Update Gender");
		System.out.println("                                  4.Update Address  \n ");
		System.out.print("                                  :-  ");
	}
	
	public static void Timeline()
	{
		System.out.println("\n                                                        ");
		System.out.println("                                  1.Create a Post");
		System.out.println("                                  2.See all post's   ");
		System.out.println("                                  3.Show my posts");
		System.out.println("                                  4.To main menu");
		System.out.print("                                   :-  ");
	}
	
	public static void likesDislikesdelete()
	{
		System.out.println(" ");
		System.out.println("                             1.Like    2.Dislike  3.Delete this post 4.Return Menu 5.Skip");
		System.out.print("                              : ");
	}
	
	public static void likesDislikes()
	{
		System.out.println(" ");
		System.out.println("                             1.Like    2.Dislike  3.Return Menu 4.Skip");
		System.out.print("                              : ");
	}
	
	
	
	//
}
