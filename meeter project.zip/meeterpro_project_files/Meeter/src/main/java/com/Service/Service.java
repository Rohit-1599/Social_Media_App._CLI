package com.Service;

import CustomExceptions.CusExceptions;
import Dataaccess.Accesser;

import java.util.Scanner;

import com.Decoretor.Printer;


public class Service
{
	int choice;
	
	public void loginService() throws Exception
	{
		String username;
		String password;
		int userid;
		boolean passauthenticate;
		boolean userauthenticate;
		
		
		CusExceptions co = new CusExceptions();
		Scanner sc = new Scanner(System.in);
		Accesser acc = new Accesser();
		
	
		System.out.print("\n                               Enter the username: "); /* This part takes in a user name and password and checks for its validity 
																					1.if valid then the user will be logged in to his profile else directed to the previous page 
																					2. logged user fuctionality is called after the successfull authentication of the username and the password*/
		username =sc.next();
		
		
		if(username!=null)
		{
			userid = acc.usernamechk(username);
			
			if(userid == 0)
			{
				throw co.NoSuchUser();
			}		
			else
			{
				userauthenticate =true;
			}
		}
		
		else
		{
			throw co.emptyusername();
		}
		
		System.out.print("\n                               Enter the password: ");
		password =sc.next();
		if(password!=null)
		{
			if(password.length()<5 && password.length()>10)
			{
				throw co.passworderror();
			}
			else
			{
				passauthenticate = acc.userpasschk(username,password);
			
				if(passauthenticate == false)
				{
					throw co.invalidPass();
				}	
				else
				{
					passauthenticate = true;
				}
			}
		}
		else
		{
			throw co.passwordEmpty();
		}

		// Check and log the user in if valid
		//providing the user services.
		String ans="yes";
		if(userauthenticate ==true && passauthenticate ==true)
		{
		   do
		   {
			Printer.logo();
			System.out.print("\n                                      Welcome: ");
			
			Printer.loggedinmenu();
			
		    switch( sc.nextInt())
		    {
		    	case 1: acc.myProfile(userid);
		    		  break;
		    		  
		    	case 2: acc.allProfiles();
		    			break;
		    			
		    	case 3: acc.updateProfile(userid);
		    			break;
		    	
		    	case 4: acc.timeline(userid,username);
		    			break; 
		    	
		    	default: ans = "yes";
		    }
			System.out.print("\n\n                             Do you want to continue with log menu(yes/no): ");
			ans = sc.next();
		   }while(ans.equalsIgnoreCase("yes"));
		   
		}
	
	}
	
	
	public void signUpService() throws Exception
	{
		String username;
		String password;
		String email;
		int userid = 0;
		
		
		CusExceptions co = new CusExceptions();
		Scanner sc = new Scanner(System.in);
		Accesser acc = new Accesser();
		
		boolean ans =true;
		System.out.println("                Welcome to the Meeter. All your friend'S are here.");
		while(ans == true)
		{
			try 
			{
				System.out.print("\n                          Enter a unique user name: ");
				username = sc.next();
				
				if(username!=null)
				{ 
					
					userid = acc.setUserName(username);
					ans = false;
					
				}
				else
				{
					throw co.emptyusername();
				}	
			}
			catch(Exception e)
			{
				
				ans =true;
			}	
		}
		ans =true;
		while(ans ==true)
		{
		    try
			{
				System.out.print("\n                           Enter a password: ");
				 password = sc.next();
				
				if(password!=null )
				{ 
					
					if(password.contains(" ")==false)
					{
						if( password.length()>=5 && password.length()<=10)
						{
							acc.setpassword(userid,password);
							ans =false;
						}
						else
						{
							throw co.passworderror();
						}
					}
					else
					{
						throw co.spass();
					}
				}
				else
				{
					throw co.passwordEmpty();
				}	
			}
			catch(Exception e)
			{
				ans =true;
				System.err.println("                            This password is invalid enter a valid password");
			
			}
		}
		ans = true;
		while(ans ==true)
		{
			try 
			{
				System.out.print("\n                          Enter the Email address:");
				String temp = sc.next();
				if( temp.contains("@gmail.com") )
				{
					acc.setemail(userid,temp );
					ans =false;
				}	
			}
			catch(Exception e)
			{
				ans =true;
				System.err.println("                            This email is invalid enter a valid email");
			}
		}	
		
		ans = true;
		while(ans ==true)
		{
			try 
			{
				System.out.print("\n                          Enter the Gender :");
				String gender= sc.next();
				if(gender.equalsIgnoreCase("male")==true ||gender.equalsIgnoreCase("female")==true )
				{
					acc.setgender(userid, gender);
					ans =false;
				}
				else
				{
					co.ingen();
				}
			}
			catch(Exception e)
			{
				
			}
		}	
		ans = true;
		while(ans ==true)
		{
			try 
			{
				System.out.print("\n                          Enter the Address :");
				String add= new Scanner(System.in).nextLine();
				if(add.length()>0&&add.length()<=100 )
				{
					acc.setadd(userid, add);
					ans =false;
				}
				else
				{
					co.inadd();
				}
			}
			catch(Exception e)
			{
				
			}
		}	
	  System.out.println("\n\n                         Signed in successfully!");	
    }
	
}
