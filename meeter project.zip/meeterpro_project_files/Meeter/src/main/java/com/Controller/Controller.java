package com.Controller;

import com.Service.Service;

public class Controller
{
	Service s = new Service();
		public void login()
		{
				try
				{
					s.loginService();
				}
				catch(Exception e)
				{	
				}
		}
		
		public void signUp()
		{
			try
			{
				s.signUpService();
			}
			catch(Exception e)
			{
				
			}
		}
}
