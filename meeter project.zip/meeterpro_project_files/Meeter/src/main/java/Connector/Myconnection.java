package Connector;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class Myconnection
{
	Properties prop = new Properties();
	public static Connection giveConn() throws Exception
	{
		Properties prop = new Properties();
		prop.load(new FileReader("C:\\Users\\HP\\Desktop\\final copy\\meeterpro.zip_expanded\\Meeter\\src\\main\\java\\resources\\props.properties"));
		Connection con = DriverManager.getConnection(prop.getProperty("url"),prop.getProperty("username"),prop.getProperty("password"));
		
		return con;
	}
	
}
