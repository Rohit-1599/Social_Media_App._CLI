package Dataaccess;

import java.sql.*;
import java.util.Scanner;
import com.Decoretor.Printer;
import Connector.Myconnection;
import CustomExceptions.CusExceptions;

public class Accesser
{
	private Connection conn;
	private PreparedStatement stmt;
	private ResultSet r;
	private Statement cs;
	
	private Scanner sc = new Scanner(System.in);
	
	{
		try
		{
		    conn = Myconnection.giveConn();
		    if(conn == null)
		    {
		    	throw CusExceptions. NoConnection();
		    }
	    }
		catch(Exception e)
		{
			
		}
	} 
	
	public int usernamechk(String username) throws Exception
	{
		stmt = conn.prepareStatement("SELECT Userid ,username FROM userinfo where username = ?");
		stmt.setString(1,username);
		r = stmt.executeQuery();
		
		 int userid = 0;
		 try 
		 {
			 
			 while(r.next())
			 {
				if(username.equals(r.getString(2)))
				{
				  userid = r.getInt(1);
				}
				else
				{
					CusExceptions cus = new CusExceptions();
					throw cus.NoSuchUser();
				}
			}
				 
		 }
		 catch(Exception e)
		 {
		 	if(e.getMessage().contains("empty"))
		 	{
		 		userid = 0;
		 	}
		 }
	
		 return userid;
	}
	
	public boolean userpasschk(String username ,String pass) throws Exception
	{

		stmt = conn.prepareStatement("SELECT upass FROM userinfo WHERE Username = ?");
		stmt.setString(1,username);
		r = stmt.executeQuery();
		boolean checked =false;
		String temp ="";
		while(r.next())
		{
			temp = r.getString(1);
		}
		try
		{
		  checked = temp.equals(pass);
		}
		catch(Exception e)
		{
			checked =false;
		}
			
		return checked;	
	}
	
	
	
	//after login section here :-
	
	public void myProfile(int userid) throws Exception
	{
		cs = conn.createStatement();
		r = cs.executeQuery("SELECT * FROM Userinfo WHERE userid = "+userid);
		
		System.out.println("\n");
		System.out.println("                  username 	     email           gender               address \n");
		while(r.next())
		{
			System.out.println("                    "+r.getString(2)+"       "+r.getString(4)+"      "+r.getString(5)+"     "+r.getString(6));
		}	
	}
	
	public void allProfiles() throws Exception
	{
		cs = conn.createStatement();
		r = cs.executeQuery("SELECT * from Userinfo");
		System.out.println("                   username 	     email           gender               address \n");
		while(r.next())
		{
			System.out.println("                    "+r.getString(2)+"       "+r.getString(4)+"      "+r.getString(5)+"     "+r.getString(6));
		}	
	}
	
	public void updateProfile(int userid) throws Exception
	{
		String ans = "yes";
		while(ans.equalsIgnoreCase("yes"))
		{
			Printer.logo();
			Printer.updateMenu();
			
			int choice = sc.nextInt();
			switch(choice)
			{
				case 1: updateUsername(userid);
						break;
					
				case 2: updatePassword(userid);
						break;
						
				case 3: updateGender(userid);
						break;
				case 4: updateAddress(userid);
						break;
				default: System.err.println("             Invalid choice enter a valid option.");
						break;
			}
			
			System.out.println("                      Do you want to continue updates menu(yes/no): ");
			ans = sc.next();	
		}
		
		return;
	}
	
	public void updateUsername(int userid) throws Exception
	{
		System.out.print("                              Enter the new Username: ");
		String temp =sc.next();
		
		stmt = conn.prepareStatement("UPDATE userinfo SET Username = ? WHERE Userid =?");
		stmt.setString(1,temp);
		stmt.setInt(2, userid);
		stmt.executeUpdate();
		System.out.println("                       Your username was successfully changed!");
		
	}
	
	public void updatePassword(int userid) throws Exception
	{
		System.out.print("                              Enter the new Password: ");
		String temp =sc.next();
		
		stmt = conn.prepareStatement("UPDATE userinfo SET Upass = ? WHERE Userid =?");
		stmt.setString(1,temp);
		stmt.setInt(2, userid);
		stmt.executeUpdate();
		System.out.println("                       Your Password was successfully changed!");
		
	}
	
	public void updateGender(int userid) throws Exception
	{
		System.out.print("                              Enter the new Gender: ");
		String temp =sc.next();
		
		stmt = conn.prepareStatement("UPDATE userinfo SET gender = ? WHERE Userid =?");
		stmt.setString(1,temp);
		stmt.setInt(2, userid);
		stmt.executeUpdate();
		System.out.println("                       Your Gender was successfully changed!");
		
	}
	
	public void updateAddress(int userid) throws Exception
	{
		System.out.print("                              Enter the new Address: ");
		String temp =new Scanner(System.in).nextLine();
		
		stmt = conn.prepareStatement("UPDATE userinfo SET Address = ? WHERE Userid =?");
		stmt.setString(1,temp);
		stmt.setInt(2, userid);
		stmt.executeUpdate();
		System.out.println("                       Your Address was successfully changed!");
		
	}
	
	
	
	//Timeline handling mehtods
	
	public void timeline(int userid, String username) throws Exception
	{
		String ans = "yes";
		while(ans.equalsIgnoreCase("yes"))
		{
			Printer.logo();
			Printer.Timeline();
			
			int choice = sc.nextInt();
			System.out.println("\n");
			switch(choice)
			{
				case 1: createPost(userid);
						break;
						
				case 2: seeAllPosts();
						break;
					
				case 3: myPosts(userid,username);
						break;
				
				default: System.err.println("                   Invalid choice enter a valid option.");
						break;
			}
			
			System.out.print("                             Do you want to continue with timeline menu(yes/no): ");
			ans = sc.next();	
		}
		
		return;	
	}
	
// Post handling methods
	
	public void createPost(int userid) throws SQLException
	{
		System.out.print("                                   Enter the Message for post: ");
		String message = (new Scanner(System.in)).nextLine();
		stmt = conn.prepareStatement("INSERT INTO posts VALUES(?,DEFAULT,?,DEFAULT);");
		stmt.setInt(1, userid);
		stmt.setString(2, message);
		stmt.executeUpdate();
		System.out.println("                                        Posted successfully! "); 
	}
	
	public void myPosts(int userid, String username) throws Exception
	{
		int temp = userid;
		stmt = conn.prepareStatement("select postid,content,timeposted from posts;");
		r = stmt.executeQuery();
		
		if(r ==null)
		{
				System.err.println("                      There are no Posts yet.");
		}
		else
		{
			System.out.println("   Username= "+username);
			while(r.next())
			{
				System.out.println("\n*******************************************************************************\n");
				System.out.println("                                  PostId: "+r.getInt(1)+" \n");
				System.out.println("                                  Content: "+r.getString(2)+" \n");
				System.out.println("                                  On: "+new Date(r.getTimestamp(3).getTime())+" \n");
				System.out.println("                                  at: "+new Time(r.getTimestamp(3).getTime())+" \n\n");
				System.out.println("                                  likes: "+ likescount(r.getInt(1))+"  Dislikes: "+dislikescount(r.getInt(1)));
				
				Printer.likesDislikesdelete();
				int choice = sc.nextInt();
				
				if(choice ==1)
				{
					like(userid,r.getInt(1),"You");
				}
				 	    
				else if(choice == 2)
				{
					dislike(userid,r.getInt(1),"You");
				}
						
				else if(choice == 3 )
				{
					deletePost(r.getInt(1));
				}
				else if(choice == 4)
				{
					return;
				}
				else
				{
					continue;
				}
			}
		}
	}
	
	public void seeAllPosts() throws Exception
	{
		cs = conn.createStatement();
		r = cs.executeQuery("SELECT po.postid ,po.content ,ui.username , po.timeposted, ui.userid FROM POSTS PO JOIN USERINFO UI USING(USERID);");
		if(r==null)
		{
				System.err.println("                      There are no Posts yet.");
				
		}
		else
		{
			while(r.next())
			{	
				System.out.println("*****************************************************************************\n");
				System.out.println("                             PostId: "+r.getInt(1)+"\n");
				System.out.println("                             Content: "+r.getString(2)+" \n");
				System.out.println("                             Posted by: "+r.getString(3));
				System.out.println("                             On: "+ new Date(r.getTimestamp(4).getTime())+"       at: "+new Time(r.getTimestamp(4).getTime()));
				System.out.println("                             likes: "+ likescount(r.getInt(1))+"  Dislikes: "+dislikescount(r.getInt(1)));
				
				Printer.likesDislikes();
				int choice = sc.nextInt();
					
					if(choice == 1)
					{
						like(r.getInt(5),r.getInt(1),r.getString(3));
					}
					
					else if( choice == 2)
					{
						dislike(r.getInt(5),r.getInt(1),r.getString(3));
					}
					
					else if(choice == 3)
					{
						return;
					}
			}
		}
		
	}
	
	
	
	// Likes and Dislikes
	
	public void like(int userid,int postid,String name) throws Exception
	{
		
			cs = conn.createStatement();
			ResultSet tempr=cs.executeQuery("SELECT * FROM postPopularity where postid = '"+postid+"'and userid = '"+userid+"' group by postid ,userid ;");
			
				if(tempr.next())
				{
					System.err.println("                                       post already liked or disliked");
					stmt = conn.prepareStatement("delete from POSTPOPULARITY  WHERE postid =?  AND userid =?;");
					stmt.setInt(1, postid);
					stmt.setInt(2,userid);
					stmt.executeUpdate();
					
					stmt = conn.prepareStatement("INSERT INTO postPopularity values(?,?,1,DEFAULT);");
					stmt.setInt(1, postid);
					stmt.setInt(2,userid);
					stmt.executeUpdate();
					System.out.println("                               You liked the post "+postid+" posted by "+name);
				}
				else
				{
					stmt = conn.prepareStatement("INSERT INTO postPopularity values(?,?,1,DEFAULT);");
					stmt.setInt(1, postid);
					stmt.setInt(2,userid);
					stmt.executeUpdate();
					System.out.println("                               You liked the post "+postid+" posted by "+name);
				}
		
	}
	
	public void dislike(int userid,int postid, String name) throws Exception
	{
		cs = conn.createStatement();
		ResultSet tempr=cs.executeQuery("SELECT * FROM postPopularity where postid = '"+postid+"'and userid = '"+userid+"' group by postid ,userid ;");
		
		
		if(tempr.next())
		{
			
			System.err.println("                             The post was already liked or disliked");
			stmt = conn.prepareStatement("DELETE FROM POSTPOPULARITY where postid =? and userid =?;");
			stmt.setInt(1, postid);
			stmt.setInt(2, userid);
			stmt.executeUpdate();

			stmt = conn.prepareStatement("INSERT INTO postPopularity values(?,?,DEFAULT,1);");
			stmt.setInt(1, postid);
			stmt.setInt(2,userid);
			stmt.executeUpdate();
			System.out.println("                             You Disliked the post "+postid+" posted by "+name);

			
		}
		else
		{
			stmt = conn.prepareStatement("INSERT INTO postPopularity values(?,?,DEFAULT,1);");
			stmt.setInt(1, postid);
			stmt.setInt(2,userid);
			stmt.executeUpdate();
			System.out.println("                             You Disliked the post "+postid+" posted by "+name);
		}
	}
	
	public void deletePost(int postid)  throws Exception
	{	 
		stmt= conn.prepareStatement("DELETE FROM posts WHERE postid = ?");
		stmt.setInt(1, postid);
		stmt.executeUpdate();
		System.out.println("                                      The post was successfully deleted");
	}
	
	public int likescount(int postid) throws Exception
	{
		int temp=0;
		
		stmt = conn.prepareStatement("Select SUM(likes) from postpopularity where postid=?;");
		stmt.setInt(1, postid);
		ResultSet tempres = stmt.executeQuery();
		while(tempres.next())
		{
			temp = tempres.getInt(1);
		}
		
		
		return temp;
	}
	
	public int dislikescount(int postid) throws Exception
	{
		int temp=0;
		
		stmt = conn.prepareStatement("Select SUM(dislikes) from postpopularity where postid=?;");
		stmt.setInt(1, postid);
		ResultSet tempres = stmt.executeQuery();
		while(tempres.next())
		{
			temp = tempres.getInt(1);
		}
		
		
		return temp;
	}
	
	// sign up portion methods
	
	public int setUserName(String username) throws Exception
	{
		int userid =0;
				stmt = conn.prepareStatement("INSERT INTO USERINFO VALUES(DEFAULT,?,?,?,?,?);");
				stmt.setString(1, username);
				stmt.setString(2,"1234");
				stmt.setString(3,"abc@gmail.com");
				stmt.setString(4,"Gender");
				stmt.setString(5,"address");
				stmt.executeUpdate();
				
				stmt = conn.prepareStatement("SELECT Userid FROM userinfo where username = ?;");
				stmt.setString(1, username);
				r =stmt.executeQuery();
				while(r.next())
				{
					userid = r.getInt(1);
				}

			
			
			
		 return userid;
	}
	
	
	public void setpassword(int userid, String password) throws Exception
	{
		stmt = conn.prepareStatement("UPDATE Userinfo SET upass =? WHERE USERID = ?");
		stmt.setString(1, password);
		stmt.setInt(2, userid);
		stmt.executeUpdate();

	}
	
	public void setemail(int userid,String email) throws Exception
	{
		stmt = conn.prepareStatement("UPDATE Userinfo SET email = ? WHERE USERID = ? ;");
		stmt.setString(1, email);
		stmt.setInt(2, userid);
		stmt.executeUpdate();

	}
	
	public void setgender(int userid,String gender) throws Exception
	{
		stmt = conn.prepareStatement("UPDATE Userinfo SET gender = ? WHERE USERID = ?;");
		stmt.setString(1, gender);
		stmt.setInt(2, userid);
		stmt.executeUpdate();

	}
	
	public void setadd(int userid,String add) throws Exception
	{
		stmt = conn.prepareStatement("UPDATE Userinfo SET address =? WHERE USERID = ?");
		stmt.setString(1, add);
		stmt.setInt(2, userid);
		stmt.executeUpdate();

	}
}
